<?php

/**
 * MessageSize configuration file
 */

// Max total attachment size limit
$rcmail_config['max_message_size'] = "10MB";

?>