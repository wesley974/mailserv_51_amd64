<?php

/**
 * MessageSize
 *
 * Plugin to limit the overall size of a message by restricting
 * the cumulative attachment size
 *
 * @version @package_version@
 * @author Timo Kousa
 * @modified by Philip Weir
 */
class messagesize extends rcube_plugin
{
	public $task = 'mail';

	function init()
	{
		$this->add_hook('attachment_upload', array($this, 'check_size'));
		$this->load_config();
	}

	function check_size($args)
	{
		$limit = parse_bytes(rcmail::get_instance()->config->get('max_message_size', '10MB'));
		$group = $args['group'];
		$total = $args['size'];

		if ($_SESSION['compose'] && $_SESSION['compose']['attachments']) {
			foreach ($_SESSION['compose']['attachments'] as &$attachment) {
				if ($attachment['group'] == $group) {
					// check if the size is known, if not calculate and save it
					if (empty($attachment['size']))
						$attachment['size'] = $attachment['data'] ? strlen($attachment['data']) : @filesize($attachment['path']);

					$total += $attachment['size'];
				}
			}
		}

		if ($total > $limit) {
			$this->add_texts('localization/');
			$args['error'] = sprintf($this->gettext('overallsizeerror'), show_bytes(parse_bytes($limit)));
			$args['abort'] = true;
		}

		return $args;
	}
}

?>