<?php header( 'Location: webmail/' ); ?>
